function handleClick(menuName) {
    alert('Anda memilih: ' + menuName);
}
